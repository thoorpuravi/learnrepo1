package com.ravi.learn.core.services.impl;

import com.day.cq.dam.api.Asset;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.ravi.learn.core.services.FetchAssetTitleJsonService;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.osgi.service.component.annotations.Component;

import java.util.Iterator;

@Component(service = FetchAssetTitleJsonService.class, immediate = true)
public class FetchAssetTitleJsonImpl implements FetchAssetTitleJsonService{

    @Override
    public JsonObject fetchAssetTitleJson(String damPath, ResourceResolver resourceResolver) {
        JsonArray assetDetailArray = new JsonArray();
        JsonObject result = new JsonObject();
        if(StringUtils.isNotEmpty(damPath) && resourceResolver != null) {
            Resource damResource = resourceResolver.resolve(damPath);
            if(!ResourceUtil.isNonExistingResource(damResource)) {
                if (damResource.hasChildren()) {
                    Iterator<Resource> resourceIterator = damResource.listChildren();
                    while (resourceIterator.hasNext()) {
                        Asset asset = resourceIterator.next().adaptTo(Asset.class);
                        JsonObject assetData = new JsonObject();
                        if(asset != null) {
                            assetData.addProperty("title", asset.getMetadata("jcr:title") != null ? asset.getMetadata("jcr:title").toString() : StringUtils.EMPTY);
                            assetData.addProperty("path", asset.getPath());
                            assetDetailArray.add(assetData);
                        }
                    }
                    result.add("assetDetails", assetDetailArray);
                }
            }
        }
        return result;
    }
}
