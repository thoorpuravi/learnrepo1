package com.ravi.learn.core.services;

import com.google.gson.JsonObject;
import org.apache.sling.api.resource.ResourceResolver;

public interface FetchAssetTitleJsonService {

    JsonObject fetchAssetTitleJson(String damPath, ResourceResolver resourceResolver);
}
